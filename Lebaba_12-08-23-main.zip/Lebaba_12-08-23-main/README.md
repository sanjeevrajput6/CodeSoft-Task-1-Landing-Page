# Lebaba_12-08-23
Learn how to build a stunning and responsive E-commerce website landing page from scratch using HTML and CSS
